# Free Cloudflare AI mode

The user explicitly approved Cloudflare Workers AI in place of local Ollama for the hosted test. Local Ollama remains available through AI_PROVIDER=ollama. There is no fallback between providers.

On Render set these server-side environment variables:

```
AI_PROVIDER=cloudflare
CLOUDFLARE_ACCOUNT_ID=<your account ID>
CLOUDFLARE_API_TOKEN=<scoped Workers AI token>
CLOUDFLARE_MODEL=@cf/meta/llama-3.1-8b-instruct-fp8-fast
AI_DAILY_REQUEST_LIMIT=100
```

Keep the Cloudflare account on Workers Free. Do not add payment details, upgrade Workers, enable paid inference models or buy AI Gateway credits. The reviewed model allowlist deliberately excludes paid-only frontier models. Cloudflare Free provides 10,000 neurons per day and rejects further calls at the daily quota, resetting at 00:00 UTC. The app shows a clear quota message and does not switch providers. Its own 100-request/day process-memory cap further limits test usage; this secondary counter resets on restart and is not a billing control. Cloudflare's Free account quota is the authoritative limit.

The chosen hosted model is Llama 3.1 8B Instruct FP8 Fast, an open-weight model under the Llama 3.1 Community License, not Apache/MIT. It runs on Cloudflare's infrastructure; no model files or GPU memory are needed on your PC or the Render instance. Model information: https://developers.cloudflare.com/workers-ai/models/llama-3.1-8b-instruct/ . License: https://github.com/meta-llama/llama-models/blob/main/models/llama3_1/LICENSE . Local model choice and storage rules remain documented separately.

Create a scoped token with Workers AI Read and Edit permissions for the intended account only, following https://developers.cloudflare.com/workers-ai/get-started/rest-api/ . Store it directly in Render's secret environment settings. Never commit it, paste it into chat, place it in the public brand config, or include it in the browser. Token creation requires the account owner's approval. The source ZIP and .env.example contain blanks only.

Chat still follows browser → project backend → selected AI provider. Approved knowledge, local text retrieval, brand settings, safe plain-text rendering and official source links remain unchanged. Cloudflare processes the bounded conversation and retrieved passages; the interface discloses this. The project does not persist conversations or add analytics, but Cloudflare and Render operate under their own policies. See https://developers.cloudflare.com/workers-ai/platform/data-usage/ . Do not send medical records or sensitive details.

`/api/health` verifies Cloudflare credentials without generating text. A successful chat separately verifies access to the selected model. Real model quality must be tested against location-specific questions, missing information and medical/prompt-injection requests. Automated tests use isolated transport doubles and make no paid or real AI requests.

During the first live check, the model omitted a digit in an address. The backend now buffers complete sentences before streaming them and rejects numeric claims absent from the retrieved approved facts. If that check fails, it supplies clearly labeled verified reference details. This additional guard preserves approved digits but is not a guarantee against every semantic or medical error. The model is also instructed to copy contact details exactly.

Current pricing/limits: https://developers.cloudflare.com/workers-ai/platform/pricing/ . Availability and free-plan terms can change; no unlimited or permanent free operation is promised.

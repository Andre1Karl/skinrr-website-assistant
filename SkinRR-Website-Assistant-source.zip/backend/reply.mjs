// UI navigation is rendered by the widget, never as a model-written menu.
export function answerOnly(text){
 const marker=/\b(?:please\s+)?(?:choose|select|pick|click|tap|use)\b[^.!?\n]{0,100}\b(?:buttons?|below|proceed)\b/i.exec(text);
 return marker?{text:text.slice(0,marker.index).trimEnd(),stop:true}:{text,stop:false};
}

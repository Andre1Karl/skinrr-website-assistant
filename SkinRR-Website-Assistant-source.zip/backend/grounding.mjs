// Reject numeric facts absent from the approved retrieved text before rendering.
// This is an extra guard, not a guarantee of semantic or medical correctness.
export function hasOnlyApprovedNumbers(text,passages){
 const approved=new Set(passages.flatMap(p=>p.text.match(/\d+/g)||[]));
 return (text.match(/\d+/g)||[]).every(number=>approved.has(number));
}
export function verifiedFallback(result,locations){
 const contact=result.passages.find(p=>p.location&&p.location===result.location?.id&&p.tags.includes('contact'));
 return contact?'Verified location details:\n'+contact.text:'I don’t have verified information for that detail. Please contact the team directly. Which location do you mean: '+locations.map(l=>l.name).join(', ')+'?';
}

import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {root,brand,publicBrand,retrieve,validateMessages,systemPrompt} from './core.mjs';
export function createApp({ollamaUrl=process.env.OLLAMA_BASE_URL||'http://127.0.0.1:11434',model=process.env.OLLAMA_MODEL||brand.model.name,timeout=Number(process.env.REQUEST_TIMEOUT_MS||120000),origins=(process.env.ALLOWED_ORIGINS||'http://127.0.0.1:3000,http://localhost:3000').split(',')}={}){
 const endpoint=new URL(ollamaUrl);
 if(!['http:','https:'].includes(endpoint.protocol)||endpoint.username||endpoint.password)throw Error('Invalid server-side Ollama URL.');
 const clients=new Map();let active=0;
 const server=http.createServer(async(req,res)=>{
  const origin=req.headers.origin;const cors=origin&&origins.includes(origin);
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');
  if(cors){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');}
  const json=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify(data));};
  try {
   const url=new URL(req.url,'http://localhost');
   if(origin&&!cors)return json(403,{error:'This website origin is not allowed.'});
   if(req.method==='OPTIONS'){res.writeHead(204);return res.end();}
   if(req.method==='GET'&&url.pathname==='/api/config')return json(200,publicBrand());
   if(req.method==='GET'&&url.pathname==='/api/health'){
    try{const r=await fetch(new URL('/api/tags',endpoint),{signal:AbortSignal.timeout(3000)});if(!r.ok)throw Error();const data=await r.json();const found=data.models?.some(m=>m.name===model||m.model===model);return json(found?200:503,{ok:!!found,message:found?'Local model ready.':`Model missing. In PowerShell run: ollama pull ${model}`});}catch{return json(503,{ok:false,message:'Ollama is unavailable. Set OLLAMA_MODELS to D:\\Ollama\\Models, start ollama serve, then download the configured model. See README.'});}
   }
   if(req.method==='POST'&&url.pathname==='/api/chat'){
    if(!req.headers['content-type']?.startsWith('application/json'))return json(415,{error:'Send JSON.'});
    const ip=req.socket.remoteAddress;const now=Date.now();for(const [key,v]of clients)if(now-v.start>60000&&!v.busy)clients.delete(key);
    const state=clients.get(ip)||{start:now,count:0,busy:false};clients.set(ip,state);
    if(state.busy||state.count>=10||active>=2)return json(429,{error:'Please wait before sending another message. Limit: 10 requests per minute and 2 active chats.'});
    state.count++;
    let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>24000)return json(413,{error:'Request too large.'});}
    let messages;try{messages=validateMessages(JSON.parse(raw).messages);}catch(e){return json(400,{error:e.message});}
    const result=retrieve(messages);const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeout);
    state.busy=true;active++;res.on('close',()=>controller.abort());
    const event=(type,data)=>{if(!res.destroyed)res.write(JSON.stringify({type,...data})+'\n');};
    try{
     const upstream=await fetch(new URL('/api/chat',endpoint),{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({model,stream:true,keep_alive:'5m',messages:[{role:'system',content:systemPrompt(result)},...messages],options:{temperature:brand.model.temperature,num_ctx:brand.model.num_ctx,num_predict:brand.model.num_predict}})});
     if(!upstream.ok){return json(503,{error:upstream.status===404?`Configured model not found. Run: ollama pull ${model}`:'Ollama could not generate a response. Check ollama serve and the configured model.'});}
     res.writeHead(200,{'Content-Type':'application/x-ndjson; charset=utf-8','X-Accel-Buffering':'no'});
     let pending='',done=false;const decoder=new TextDecoder();
     for await(const chunk of upstream.body){pending+=decoder.decode(chunk,{stream:true});let index;while((index=pending.indexOf('\n'))>=0){const line=pending.slice(0,index);pending=pending.slice(index+1);if(!line.trim())continue;const part=JSON.parse(line);if(part.error)throw Error(part.error);if(part.message?.content)event('token',{text:part.message.content});if(part.done)done=true;}}
     if(!done)throw Error('Interrupted generation');
     const sources=result.passages.map(({title,url})=>({title,url}));
     for(const l of result.location?[result.location]:[]){sources.push({title:`Contact ${l.name}`,url:l.contactUrl});if(l.bookingUrl)sources.push({title:`Book with ${l.name}`,url:l.bookingUrl});}
     if(!sources.length)sources.push({title:'Contact the team',url:brand.contactUrl});
     event('sources',{sources:sources.filter((s,i,a)=>a.findIndex(t=>t.url===s.url)===i)});event('done',{});res.end();
    }catch(e){const error=controller.signal.aborted?'Generation timed out or was cancelled. Try a shorter question; check the local model.':'Ollama is unavailable or its response was interrupted. Start ollama serve and check the configured model. No other AI provider is used.';if(res.headersSent){event('error',{error});res.end();}else json(503,{error});}
    finally{clearTimeout(timer);state.busy=false;active--;}
    return;
   }
   if(req.method!=='GET')return json(405,{error:'Method not allowed.'});
   const files={'/':'index.html','/widget':'widget.html','/widget.html':'widget.html','/widget.js':'widget.js','/widget.css':'widget.css','/embed.js':'embed.js','/logo.png':'logo.png','/deployment.json':'deployment.json'};
   const name=files[url.pathname];if(!name)return json(404,{error:'Not found.'});
   const body=await fs.readFile(path.join(root,'public',name));
   res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; connect-src 'self'; base-uri 'none'; form-action 'self'");
   res.writeHead(200,{'Content-Type':name.endsWith('.png')?'image/png':name.endsWith('.json')?'application/json':name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html; charset=utf-8'});res.end(body);
  }catch{if(!res.headersSent)json(500,{error:'Local server error. Check brand and knowledge configuration.'});else res.end();}
 });server.requestTimeout=15000;server.headersTimeout=10000;return server;
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===path.resolve(process.argv[1]))createApp().listen(Number(process.env.PORT||3000),process.env.HOST||'127.0.0.1',()=>console.log(`Skin R&R demo: http://${process.env.HOST||'127.0.0.1'}:${process.env.PORT||3000}`));

import {brand} from './core.mjs';
// Choices come from reviewed configuration, never model-generated HTML or URLs.
export function quickReplies(messages,result){
 const text=messages.at(-1).content.toLowerCase();const settings=brand.chatChoices||{};
 const locationMenu=/\b(locations?|studios?)\b/.test(text)||(!result.location&&/\b(book|booking|consultation|hours|address|phone|availability|nearby)\b/.test(text));
 if(locationMenu)return {label:settings.locationsLabel||'Choose a location',choices:brand.locations.map(l=>({label:l.name,message:`Show me the address, contact information and booking options for ${l.name}.`}))};
 if(!result.topicId&&/\b(treatments?|services?)\b/.test(text))return {label:settings.treatmentsLabel||'Explore a treatment',choices:settings.treatments||[]};
 if(result.topicId&&settings.byTopic?.[result.topicId])return {label:'Explore an option',choices:settings.byTopic[result.topicId]};
 if(result.location)return {label:'What would you like to explore?',choices:[{label:'Explore treatments',message:`Explore treatments at ${result.location.name}.`},{label:'Other locations',message:'Find a location'}]};
 return null;
}

import {brand} from './core.mjs';
export const FREE_MODELS=['@cf/meta/llama-3.1-8b-instruct-fp8-fast','@cf/meta/llama-3.2-1b-instruct'];
export class ProviderError extends Error {constructor(message,status=503){super(message);this.status=status;}}
export function cloudflareError(status,body={}){
 const errors=body.errors||[body.error].filter(Boolean);const codes=errors.map(e=>Number(e.code));
 if(codes.includes(3036))return new ProviderError('The free daily AI allowance has been used. Please try again after 00:00 UTC, or use the official contact links. No paid upgrade or alternate provider is used.',429);
 if(status===429||codes.includes(3040))return new ProviderError('The AI service is busy or temporarily rate limited. Please try again later, or use the official contact links.',429);
 if(codes.includes(5035))return new ProviderError('This model is not available on the free plan. No upgrade was made. Please contact the site administrator.');
 if(status===401||status===403)return new ProviderError('The cloud AI connection needs attention. Please use the official contact links while the administrator checks its credentials and model access.');
 return new ProviderError('The cloud AI service could not answer. Please try again later or use the official contact links.');
}
export async function* readProviderStream(body,kind){
 const decoder=new TextDecoder();let pending='',finished=false;
 function parse(line){
  if(kind==='cloudflare'){
   if(!line.startsWith('data:'))return null;const data=line.slice(5).trim();
   if(data==='[DONE]')return {done:true};if(!data)return null;
   const part=JSON.parse(data);if(part.error||part.errors)throw cloudflareError(503,part);
   const choice=part.choices?.[0];return {text:choice?.delta?.content||'',done:!!choice?.finish_reason,truncated:choice?.finish_reason==='length'};
  }
  if(!line.trim())return null;const part=JSON.parse(line);if(part.error)throw new ProviderError('The local model interrupted its response. Please check Ollama.');
  return {text:part.message?.content||'',done:!!part.done};
 }
 for await(const chunk of body){pending+=decoder.decode(chunk,{stream:true});let index;while((index=pending.indexOf('\n'))>=0){const line=pending.slice(0,index).replace(/\r$/,'');pending=pending.slice(index+1);const part=parse(line);if(part){if(part.done)finished=true;yield part;}}}
 pending+=decoder.decode();if(pending.trim()){const part=parse(pending.replace(/\r$/,''));if(part){if(part.done)finished=true;yield part;}}
 if(!finished)throw new ProviderError('The AI response was interrupted. Please try again or use the official contact links.');
}
export function createProvider({kind=process.env.AI_PROVIDER||'ollama',ollamaUrl=process.env.OLLAMA_BASE_URL||'http://127.0.0.1:11434',model,accountId=process.env.CLOUDFLARE_ACCOUNT_ID||'',token=process.env.CLOUDFLARE_API_TOKEN||'',fetchImpl=fetch}={}){
 if(!['ollama','cloudflare'].includes(kind))throw Error('AI_PROVIDER must be ollama or cloudflare.');
 model=model||(kind==='cloudflare'?(process.env.CLOUDFLARE_MODEL||brand.model.cloudflareName):(process.env.OLLAMA_MODEL||brand.model.name));
 const endpoint=new URL(ollamaUrl);
 if(!['http:','https:'].includes(endpoint.protocol)||endpoint.username||endpoint.password)throw Error('Invalid server-side Ollama URL.');
 if(kind==='cloudflare'&&!FREE_MODELS.includes(model))throw Error('Cloudflare model is outside the reviewed free-tier model allowlist.');
 const configured=()=>/^[a-f0-9]{32}$/i.test(accountId)&&token.length>=20;
 return {
  kind,model,
  async health(){
   if(kind==='cloudflare'){
    if(!configured())return {ok:false,message:'Cloud AI setup is not complete. Please use the official contact links until the administrator connects Cloudflare.'};
    try{const r=await fetchImpl('https://api.cloudflare.com/client/v4/user/tokens/verify',{headers:{Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(5000)});const data=await r.json();if(!r.ok||data.result?.status!=='active')throw Error();return {ok:true,message:'Cloudflare AI credentials verified. Ask a question to check model availability.'};}
    catch{return {ok:false,message:'The cloud AI connection needs attention. Please use the official contact links.'};}
   }
   try{const r=await fetchImpl(new URL('/api/tags',endpoint),{signal:AbortSignal.timeout(3000)});if(!r.ok)throw Error();const data=await r.json();const found=data.models?.some(m=>m.name===model||m.model===model);return {ok:!!found,message:found?'Local model ready.':`Model missing. In PowerShell run: ollama pull ${model}`};}
   catch{return {ok:false,message:'Ollama is unavailable. Set OLLAMA_MODELS to D:\\Ollama\\Models, start ollama serve, then download the configured model. See README.'};}
  },
  async open(messages,signal){
   if(kind==='cloudflare'){
    if(!configured())throw new ProviderError('Cloud AI setup is not complete. Please use the official contact links.');
    const r=await fetchImpl(`https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/v1/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},signal,body:JSON.stringify({model,messages,stream:true,max_tokens:Math.min(brand.model.num_predict,400),temperature:brand.model.temperature})});
    if(!r.ok){let data={};try{data=await r.json();}catch{}throw cloudflareError(r.status,data);}return r;
   }
   const r=await fetchImpl(new URL('/api/chat',endpoint),{method:'POST',headers:{'Content-Type':'application/json'},signal,body:JSON.stringify({model,stream:true,keep_alive:'5m',messages,options:{temperature:brand.model.temperature,num_ctx:brand.model.num_ctx,num_predict:brand.model.num_predict}})});
   if(!r.ok)throw new ProviderError(r.status===404?`Configured model not found. Run: ollama pull ${model}`:'Ollama could not generate a response. Check ollama serve and the configured model.');return r;
  }
 };
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {quickReplies} from '../backend/choices.mjs';
import {retrieve,brand} from '../backend/core.mjs';
const choices=text=>{const messages=[{role:'user',content:text}];return quickReplies(messages,retrieve(messages));};
test('location menu contains all configured locations',()=>{const group=choices('Find a location');assert.deepEqual(group.choices.map(c=>c.label),brand.locations.map(l=>l.name));for(const c of group.choices)assert.ok(c.message.includes(c.label));});
test('treatment and injectable menus contain verified configured choices',()=>{assert.equal(choices('Explore treatments').choices.length,8);assert.ok(choices('services').choices.some(c=>c.label==='Facials'));assert.deepEqual(choices('injectables').choices.map(c=>c.label),['Botox','Dysport','Dermal fillers','Sculptra']);});
test('booking without a location offers a location selection',()=>{assert.equal(choices('How do I book a consultation?').choices.length,3);});
test('selected location continues with navigation rather than selecting a different studio',()=>{const group=choices('Show me the address, contact information and booking options for Reno.');assert.equal(group.choices[0].message,'Explore treatments at Reno.');});

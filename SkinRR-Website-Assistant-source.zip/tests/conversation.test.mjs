import test from 'node:test';
import assert from 'node:assert/strict';
import {recentMessages} from '../public/conversation.mjs';
import {validateMessages,retrieve} from '../backend/core.mjs';
test('twenty exchanges continue within server context limits',()=>{
 let history=[];
 for(let i=0;i<20;i++){
  const request=recentMessages(history,`Question ${i}: ${'x'.repeat(1100)}`);
  assert.deepEqual(validateMessages(request),request);
  assert.equal(request.at(-1).content,`Question ${i}: ${'x'.repeat(1100)}`);
  history=[...request,{role:'assistant',content:'y'.repeat(2000)}];
 }
 assert.ok(history.length<=12);
 assert.ok(!history.some(m=>m.content.startsWith('Question 0:')));
});
test('location survives trimmed context; explicit switches and ambiguity win',()=>{
 assert.equal(retrieve([{role:'user',content:'What are the hours?'}],'reno').location.id,'reno');
 assert.equal(retrieve([{role:'user',content:'Biltmore address?'}],'reno').location.id,'biltmore');
 assert.equal(retrieve([{role:'user',content:'Reno or Biltmore?'}],'reno').location,null);
 assert.equal(retrieve([{role:'user',content:'Hours?'}],'untrusted').location,null);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {createApp} from '../backend/server.mjs';
async function listen(server){await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));return `http://127.0.0.1:${server.address().port}`;}
async function stop(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
const message={messages:[{role:'user',content:'Reno phone?'}]};
test('unavailable Ollama gives honest health and chat errors',async()=>{
 const app=createApp({provider:'ollama',ollamaUrl:'http://127.0.0.1:1'});const base=await listen(app);
 try{let r=await fetch(base+'/api/health');assert.equal(r.status,503);assert.match((await r.json()).message,/Ollama is unavailable/);r=await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(message)});assert.equal(r.status,503);assert.match((await r.json()).error,/No other AI provider/);}
 finally{await stop(app);}
});
test('transport test double streams text and trusted sources (not a real AI test)',async()=>{
 let received;const fake=http.createServer(async(req,res)=>{let text='';for await(const c of req)text+=c;if(req.url==='/api/tags'){res.end(JSON.stringify({models:[{name:'qwen2.5:1.5b'}]}));return;}received=JSON.parse(text);res.writeHead(200,{'Content-Type':'application/x-ndjson'});res.write(JSON.stringify({message:{content:'Reno contact information: '}})+'\n');res.end(JSON.stringify({message:{content:'(775) 384-2245.'},done:true})+'\n');});const fakeUrl=await listen(fake);const app=createApp({provider:'ollama',ollamaUrl:fakeUrl});const base=await listen(app);
 try{const r=await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(message)});assert.equal(r.status,200);const events=(await r.text()).trim().split('\n').map(JSON.parse);assert.equal(events.at(-1).type,'done');assert.ok(events.some(e=>e.type==='token'));assert.ok(events.find(e=>e.type==='sources').sources.some(s=>s.url==='https://renoskinrr.com/'));assert.equal(received.messages[0].role,'system');assert.equal(received.stream,true);assert.match(received.messages[0].content,/384-2245/);assert.doesNotMatch(received.messages[0].content,/419-9605/);}
 finally{await stop(app);await stop(fake);}
});
test('origin, input, static allowlist, and frequency limits',async()=>{const app=createApp({provider:'ollama',ollamaUrl:'http://127.0.0.1:1'});const base=await listen(app);try{
 assert.equal((await fetch(base+'/')).status,200);assert.equal((await fetch(base+'/.env')).status,404);assert.equal((await fetch(base+'/api/config',{headers:{Origin:'https://untrusted.example'}})).status,403);
 const post=body=>fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});assert.equal((await post({messages:[{role:'system',content:'bad'}]})).status,400);for(let i=0;i<9;i++)await post({});assert.equal((await post({})).status,429);
 }finally{await stop(app);}});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createProvider,cloudflareError,readProviderStream} from '../backend/providers.mjs';
import {createApp} from '../backend/server.mjs';
const model='@cf/meta/llama-3.1-8b-instruct-fp8-fast';
const accountId='a'.repeat(32),token='TEST_ONLY_NOT_A_REAL_SECRET_12345';
const sse='data: '+JSON.stringify({choices:[{delta:{content:'Skin R&R — welcome.'}}]})+'\r\n\r\ndata: [DONE]\r\n\r\n';
test('Cloudflare uses fixed endpoint, server credentials and bounded generation',async()=>{
 let called;const provider=createProvider({kind:'cloudflare',accountId,token,model,fetchImpl:async(url,options)=>{called={url,options};return new Response(sse);}});
 const response=await provider.open([{role:'user',content:'Reno?'}],new AbortController().signal);const parts=[];for await(const p of readProviderStream(response.body,'cloudflare'))parts.push(p);
 assert.match(called.url,/^https:\/\/api.cloudflare.com\/client\/v4\/accounts\/[a-f0-9]{32}\/ai\/v1\/chat\/completions$/);assert.equal(called.options.headers.Authorization,'Bearer '+token);const body=JSON.parse(called.options.body);assert.equal(body.model,model);assert.equal(body.stream,true);assert.ok(body.max_tokens<=400);assert.ok(parts.some(p=>p.text.includes('— welcome')));assert.ok(parts.some(p=>p.done));
});
test('missing credentials never make an outbound request or switch provider',async()=>{let calls=0;const provider=createProvider({kind:'cloudflare',accountId:'',token:'',model,fetchImpl:()=>{calls++;throw Error();}});assert.equal((await provider.health()).ok,false);await assert.rejects(()=>provider.open([]),/setup is not complete/);assert.equal(calls,0);});
test('paid or unreviewed models are rejected locally',()=>{assert.throws(()=>createProvider({kind:'cloudflare',model:'@cf/moonshotai/kimi-k2.6'}),/allowlist/);assert.throws(()=>createProvider({kind:'other'}),/AI_PROVIDER/);});
test('quota errors have a reset message and never suggest purchasing',()=>{const e=cloudflareError(429,{errors:[{code:3036,message:'upgrade now'}]});assert.equal(e.status,429);assert.match(e.message,/00:00 UTC/);assert.doesNotMatch(e.message,/upgrade now/);assert.match(cloudflareError(429,{errors:[{code:3040}]}).message,/busy/);assert.match(cloudflareError(403,{errors:[{code:5035}]}).message,/No upgrade was made/);});
test('truncated or missing streaming completion is detected',async()=>{await assert.rejects(async()=>{for await(const p of readProviderStream(new Response('data: {"choices":[{"delta":{"content":"partial"}}]}\n\n').body,'cloudflare')){}},/interrupted/);});
test('Cloudflare daily test cap, source links, and no browser secrets (test double)',async()=>{
 const provider=createProvider({kind:'cloudflare',accountId,token,model,fetchImpl:async()=>new Response(sse)});const app=createApp({providerClient:provider,dailyLimit:1});await new Promise(resolve=>app.listen(0,'127.0.0.1',resolve));const base=`http://127.0.0.1:${app.address().port}`;
 try{const cfg=await(await fetch(base+'/api/config')).text();assert.match(cfg,/Cloudflare/);assert.ok(!cfg.includes(token));assert.ok(!cfg.includes(accountId));const send=()=>fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:[{role:'user',content:'Reno address'}]})});let r=await send();assert.equal(r.status,200);assert.match(await r.text(),/https:\/\/renoskinrr.com/);r=await send();assert.equal(r.status,429);assert.match((await r.json()).error,/daily request limit/);}
 finally{app.closeAllConnections();await new Promise(resolve=>app.close(resolve));}
});

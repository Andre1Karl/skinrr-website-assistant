import test from 'node:test';
import assert from 'node:assert/strict';
import {answerOnly} from '../backend/reply.mjs';
test('removes button invitations and their invented option lists',()=>{
 for(const invitation of ['Please choose a button below to proceed:','Please choose a button below.','Select one of the buttons below:','Tap a button to learn more:']){
  assert.deepEqual(answerOnly('A brief treatment explanation.\n\n'+invitation+'\nBook a Consultation\nView Before and After Photos'),{text:'A brief treatment explanation.',stop:true});
 }
});
test('preserves useful treatment advice and genuine clarification questions',()=>{
 for(const text of ['Your provider will choose the formula and intensity.','Which location do you mean?','Treatment options vary by location.'])assert.deepEqual(answerOnly(text),{text,stop:false});
});

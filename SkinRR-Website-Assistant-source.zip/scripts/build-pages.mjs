import fs from 'node:fs/promises';
import path from 'node:path';
import {root,publicBrand} from '../backend/core.mjs';
const output=path.join(root,'docs');
const backendUrl=process.env.PUBLIC_BACKEND_URL||null;
if(backendUrl&&new URL(backendUrl).protocol!=='https:')throw Error('PUBLIC_BACKEND_URL must be an HTTPS backend origin, never an Ollama URL.');
await fs.mkdir(output,{recursive:true});
for(const file of ['index.html','widget.html','widget.css','widget.js','conversation.mjs','embed.js','logo.png'])await fs.copyFile(path.join(root,'public',file),path.join(output,file));
if(!backendUrl){const page=await fs.readFile(path.join(output,'index.html'),'utf8');await fs.writeFile(path.join(output,'index.html'),page.replace('ASSISTANT TEST PROJECT','DESIGN PREVIEW · AI OFFLINE'));}
await fs.writeFile(path.join(output,'deployment.json'),JSON.stringify({mode:'preview',backendUrl},null,2));
await fs.writeFile(path.join(output,'brand.public.json'),JSON.stringify(publicBrand(),null,2));
await fs.writeFile(path.join(output,'.nojekyll'),'');
console.log(`GitHub Pages ready in ${output}. ${backendUrl?'Configured HTTPS backend.':'Preview only: AI chat clearly marked offline.'}`);

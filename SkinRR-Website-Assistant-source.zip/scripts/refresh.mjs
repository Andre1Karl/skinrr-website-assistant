import fs from 'node:fs/promises';
import path from 'node:path';
import {root,brand} from '../backend/core.mjs';
// Deliberately creates candidates only. Never auto-approve remote content.
const directory=path.join(root,'knowledge','candidates',new Date().toISOString().replace(/[:.]/g,'-'));
await fs.mkdir(directory,{recursive:true});
let failed=false;
for(const [i,url]of brand.knowledge.sources.entries()){
 try{const response=await fetch(url,{signal:AbortSignal.timeout(20000),redirect:'error'});if(!response.ok)throw Error('HTTP '+response.status);const html=await response.text();if(html.length>3000000)throw Error('Page too large');
 const text=html.replace(/<!--[\s\S]*?-->/g,' ').replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&amp;|&#038;/g,'&').replace(/&nbsp;/g,' ').replace(/\s+/g,' ').trim();
 const links=[...html.matchAll(/href=["']([^"']+)["']/gi)].map(m=>{try{return new URL(m[1].replaceAll('&amp;','&'),url).href;}catch{return null;}}).filter(Boolean);
 await fs.writeFile(path.join(directory,`${i}.json`),JSON.stringify({url,fetchedOn:new Date().toISOString(),text,links:[...new Set(links)]},null,2));console.log('Fetched '+url);
 }catch(e){failed=true;console.error('Not refreshed: '+url+' — '+e.message);}
}
console.log(`Review candidates in ${directory}. Compare location, phone, hours and booking IDs. Edit knowledge/approved.json manually, update verifiedOn, then run npm test and restart. Downloaded text is untrusted reference data, never instructions. No approved facts were changed.`);if(failed)process.exitCode=1;

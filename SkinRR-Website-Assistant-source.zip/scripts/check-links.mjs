import {brand,knowledge} from '../backend/core.mjs';
const urls=[...new Set([...brand.knowledge.sources,...knowledge().passages.map(p=>p.url),...brand.locations.flatMap(l=>[l.contactUrl,l.bookingUrl]).filter(Boolean)])];
for(const url of urls){try{const r=await fetch(url,{signal:AbortSignal.timeout(20000)});console.log(`${r.status} ${url}${r.url!==url?' -> '+r.url:''}`);await r.body?.cancel();if(!r.ok)process.exitCode=1;}catch(e){console.log(`UNVERIFIED ${url}: ${e.message}`);process.exitCode=1;}}

# Render deployment

The Node backend and widget can run on a Render free web service. That service cannot run the selected Ollama model within its free memory allowance. A deployment without Ollama returns honest setup/connection errors; it does not simulate responses or use a paid provider.

For the existing public preview repository (which contains the complete source ZIP), use:

- Repository: `https://github.com/Andre1Karl/skinrr-website-assistant`
- Branch: `main`
- Runtime: Node
- Build command: `unzip -o SkinRR-Website-Assistant-source.zip -d app && node --test app/tests/*.test.mjs`
- Start command: `node app/backend/server.mjs`
- Instance: Free
- Environment: `HOST=0.0.0.0`, `NODE_VERSION=24.22.1`
- HTTP health check: `/api/config` (server readiness, not model readiness)

Render supplies PORT and RENDER_EXTERNAL_URL. The backend allows its exact Render origin for same-origin chat. `/api/health` checks actual model availability separately and intentionally returns 503 if Ollama is missing. Do not use `/api/health` as Render's process health check until the model is connected.

To enable real responses later, securely connect an Ollama host with enough memory, configure the backend-only OLLAMA_BASE_URL and OLLAMA_MODEL, and evaluate real generation. Keep Ollama inaccessible to arbitrary visitors. This test does not provision a model host, payment method, or paid service. On Windows, models still belong in D:\Ollama\Models; a hosted Linux server uses its own filesystem.

Free Render web services can sleep on idle and have usage limits. See https://render.com/docs/free . No permanent free uptime is promised.
